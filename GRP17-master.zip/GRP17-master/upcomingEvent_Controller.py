class upcomingEvent_Ctr():

    def __init__(self):
        self.bind()

    def bind(self):
        self.nameView = None
        # TODO: bind model
        # self.nameModel =

    def setView(self,nameView):
        self.nameView = nameView